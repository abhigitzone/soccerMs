package com.globallogic.entity;

public enum Country {
	
	USA,
	Spain,
	Germany,
	France,
	China

}
