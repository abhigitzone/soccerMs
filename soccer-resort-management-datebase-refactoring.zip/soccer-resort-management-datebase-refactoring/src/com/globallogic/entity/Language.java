package com.globallogic.entity;

public enum Language {
	
	English,
	Spanish,
	French,
	Chinese,
	German

}
