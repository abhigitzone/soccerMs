package com.globallogic.entity;

public enum Hobby {

	Eat,
	Drink,
	WaterSports,
	Dance,
	Travel,
	Read,
	Music
	
}
